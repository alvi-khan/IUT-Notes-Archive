#include "DM.h"

DM::DM()
{
    //ctor
}

DM::DM(int a, float b)
{
    meters = a;
    centimeters = b;
}

DM::~DM()
{
    //dtor
}
