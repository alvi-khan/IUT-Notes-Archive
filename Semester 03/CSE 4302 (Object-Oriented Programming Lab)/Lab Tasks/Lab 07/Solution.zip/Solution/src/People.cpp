#include "People.h"
#include<iostream>

void People :: display()
{
    std :: cout<<"Name: "<<name<<endl;
    std :: cout<<"Age: "<<age<<endl;
    std :: cout<<"Weight: "<<weight<<endl;
}
