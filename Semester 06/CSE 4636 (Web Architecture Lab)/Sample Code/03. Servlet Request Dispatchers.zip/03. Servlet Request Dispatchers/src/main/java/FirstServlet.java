import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "FirstServlet", value = "/FirstServlet")
public class FirstServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String choice = request.getParameter("choice");
        RequestDispatcher rd1 = getServletContext().getRequestDispatcher("/AdditionServlet");
        RequestDispatcher rd2 = request.getRequestDispatcher("SubtractionServlet");

        if (choice.equalsIgnoreCase("add")) rd1.forward(request, response);
        else if (choice.equalsIgnoreCase("subtract"))   rd2.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
