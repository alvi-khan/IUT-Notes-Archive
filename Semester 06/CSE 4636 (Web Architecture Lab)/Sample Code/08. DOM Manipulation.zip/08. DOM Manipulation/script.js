// 1. Selecting an element
// selecting read-only text
let welcome_msg = document.querySelector("#welcome-msg").textContent;
// selecting user input
let email = document.querySelector("#email-input").value;

// 2. Modifying content
welcome_msg = document.querySelector("#welcome-msg");
welcome_msg.textContent = "New Welcome Message";

// 3. Handling events
print_email = function (e) {
    e.preventDefault(); // prevent page refresh so we can see console log
    email = document.querySelector("#email-input").value;
    console.log(email);
}
let submit_btn = document.querySelector(".submit");
submit_btn.addEventListener("click", print_email);

// 4. Manipulating CSS Styles
let body = document.querySelector("body");
body.style.backgroundColor = "#000000";