package com.example.lab03_assignment;

public class Item {
    public int id;
    public String name;
    public String image;
}
