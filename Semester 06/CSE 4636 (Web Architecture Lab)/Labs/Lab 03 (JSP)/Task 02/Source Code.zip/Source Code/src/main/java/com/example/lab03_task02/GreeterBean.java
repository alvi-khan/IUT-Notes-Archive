package com.example.lab03_task02;

import java.io.Serializable;

public class GreeterBean implements Serializable {
    String nameInReverse="";
    StringBuilder stringBuilder = new StringBuilder();

    public GreeterBean() {

    }

    public String getNameInReverse(String name) {
        stringBuilder.append(name);
        stringBuilder.reverse();
        nameInReverse = stringBuilder.toString();
        stringBuilder.setLength(0);
        return nameInReverse;
    }
}
