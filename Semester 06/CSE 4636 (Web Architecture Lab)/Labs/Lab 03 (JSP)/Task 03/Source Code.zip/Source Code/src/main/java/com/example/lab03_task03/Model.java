package com.example.lab03_task03;

import java.io.Serializable;
import java.util.Objects;

public class Model implements Serializable {
    String username = "adam";
    String password = "1234";
    public Model() {

    }
    public boolean verifyCredentials(String username, String password) {
        return username.equals(this.username) && password.equals(this.password);
    }
}
