import java.util.Map;

public class CookbookModel {
    private final Map<String, String> recipes = Map.of(
            "French Toast", "Butter, for greasing\n1 loaf crusty sourdough or French bread\n8 whole eggs\n2 cups whole milk\n1/2 cup whipping (heavy) cream\n1/2 cup granulated sugar\n1/2 cup brown sugar\n2 tablespoons vanilla extract",
            "Oatmeal Cookies", "2 cups packed dark brown sugar\\n1 cup (2 sticks) salted butter, softened\\n2 teaspoons vanilla extract\\n2 eggs\\n1 1/2 cups all-purpose flour\\n1 teaspoon salt\\n1/2 teaspoon baking soda\\n3 cups old-fashioned oats"
    );
    private String recipeData;

    /**
     * This method acts as a placeholder for the data retrieval process.
     * In an actual application, the recipe data would be retrieved and placed in a structure.
     * For now, the recipe is retrieved from the recipes map.
     * @param recipeName is the name of the recipe to be retrieved
     */
    public void retrieveRecipe(String recipeName) {
        recipeData = recipes.getOrDefault(recipeName, "Sorry! We don't have this recipe. :(");
    }

    /**
     * This method is used by the controller to retrieve the recipe stored in the model.
     * @return the recipe that is stored
     */
    public String getRecipeData() {
        return recipeData;
    }
}
