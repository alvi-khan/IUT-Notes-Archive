import java.util.Scanner;

public class CookbookView {
    String recipeName;

    /**
     * This method is used by the controller to initiate user input for the name of the recipe.
     */
    public void inputRecipeName() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a recipe name (try 'French Toast' or 'Oatmeal Cookies'):");
        recipeName = input.nextLine();
    }

    /**
     * This method is used by the controller to retrieve the recipe name provided by the user when passing it to the model.
     * @return the name of the recipe
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * This method is used by the controller to print the recipe retrieved from the model.
     * @param recipe is the requested recipe
     */
    public void printRecipe(String recipe) {
        System.out.println("Recipe: ");
        System.out.println(recipe);
    }
}
