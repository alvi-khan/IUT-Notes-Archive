public class Main {
    public static void main(String[] args) {
        CookbookView cookbookView = new CookbookView();
        CookbookModel cookbookModel = new CookbookModel();
        CookbookController cookbookController = new CookbookController(cookbookView, cookbookModel);

        cookbookController.inputRecipeName();
        cookbookController.getRecipe();
        cookbookController.displayRecipe();
    }
}
