public class CookbookController {
    private final CookbookModel cookbookModel;
    private final CookbookView cookbookView;

    private String recipe;

    /**
     * The controller's constructor takes a view and a model as parameters.
     */
    public CookbookController(CookbookView cookbookView, CookbookModel cookbookModel) {
        this.cookbookModel = cookbookModel;
        this.cookbookView = cookbookView;
    }

    /**
     * Updating View: Retrieve user input.
     */
    public void inputRecipeName() {
        cookbookView.inputRecipeName();
    }

    /**
     * Updating Model: Retrieve recipe based on input from view.
     */
    public void getRecipe() {
        cookbookModel.retrieveRecipe(cookbookView.getRecipeName());
        recipe = cookbookModel.getRecipeData();
    }

    /**
     * Updating View: Display requested recipe.
     */
    public void displayRecipe() {
        cookbookView.printRecipe(recipe);
    }
}
