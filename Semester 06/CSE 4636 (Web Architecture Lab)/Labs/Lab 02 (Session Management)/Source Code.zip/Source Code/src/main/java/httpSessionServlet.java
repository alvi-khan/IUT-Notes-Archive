import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class httpSessionServlet extends HttpServlet {
    int visitCount = 0;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String welcomeText = "";
        String sessionID = "";
        String creationTime = "";
        String lastVisitTime = "";

        HttpSession session = request.getSession(false);
        if (session == null) {
            session = request.getSession();
            visitCount = 0;
            welcomeText = "Welcome, Newcomer";
        }
        else {
            welcomeText = "Welcome back!";
            visitCount = visitCount + 1;
        }

        sessionID = session.getId();
        creationTime = new Date(session.getCreationTime()).toString();
        lastVisitTime = new Date(session.getLastAccessedTime()).toString();

        PrintWriter out = response.getWriter();
        out.println("<h1>" + welcomeText + "</h1>");
        out.println("<h3>Information on your session:</h3>");
        out.println("<table>\n" +
                "  <tr>\n" +
                "    <th>Info Type</th>\n" +
                "    <th>Value</th>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>Session ID</td>\n" +
                "    <td>" + sessionID +"</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>Creation Time</td>\n" +
                "    <td>" + creationTime + "</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>Time of last Access</td>\n" +
                "    <td>" + lastVisitTime + "</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>Number of previous accesses</td>\n" +
                "    <td>" + visitCount + "</td>\n" +
                "  </tr>\n" +
                "</table>");
        out.println("<form name=\"sessionEnd\" method=\"get\" action=\"endSessionServlet\">\n" +
                "    <input type=\"submit\" name=\"submit\" value=\"End Session\" />\n" +
                "  </form>");
    }
}
