package com.example.lab04;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/lab04")
public class Lab04Application extends Application {

}