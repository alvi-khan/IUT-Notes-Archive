package com.example.lab04;

import javax.json.JsonObject;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import java.io.IOException;

@WebServlet(name = "TeeShirtRequestServlet", value = "/TeeShirtRequestServlet")
public class TeeShirtRequestServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String choice1 = request.getParameter("tee-choice-1");
        String choice2 = request.getParameter("tee-choice-2");
        String choice3 = request.getParameter("tee-choice-3");
        TeeShirtRequest teeShirtRequest = new TeeShirtRequest(choice1, choice2, choice3);

        String url = "http://localhost:8080/" + request.getContextPath() + "/lab04/task3/submit/";
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(url);
        target.request().post(Entity.entity(teeShirtRequest, MediaType.APPLICATION_JSON));
        response.sendRedirect("requests.jsp");
    }
}
