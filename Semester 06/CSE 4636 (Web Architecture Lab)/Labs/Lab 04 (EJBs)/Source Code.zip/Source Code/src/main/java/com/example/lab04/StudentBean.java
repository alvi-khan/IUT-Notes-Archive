package com.example.lab04;

import java.io.Serializable;

public class StudentBean implements Serializable {
    private int id;
    private String name;
    private int semester;
    private double cgpa;
    private String phone;

    public StudentBean() {

    }

    public StudentBean(int id, String name, int semester, double cgpa, String phone) {
        this.id = id;
        this.name = name;
        this.semester = semester;
        this.cgpa = cgpa;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public double getCgpa() {
        return cgpa;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
