package com.example.lab04;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

@Path("/task1")
public class Task01Resource {
    StudentManager studentManager = new StudentManager();
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{id}")
    public StudentBean getStudentById(@PathParam("id") int id) {
        StudentBean student = studentManager.getStudent(id);
        if (student != null)    return student;
        else    return new StudentBean();
    }
}
