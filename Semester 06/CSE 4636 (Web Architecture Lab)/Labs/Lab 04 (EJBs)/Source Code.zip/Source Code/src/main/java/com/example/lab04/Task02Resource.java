package com.example.lab04;

import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

@Stateless
@Path("/task2")
public class Task02Resource {
    StudentManager studentManager = new StudentManager();
    List<StudentBean> highCGStudents = new ArrayList<>();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Lock(LockType.READ)
    @Path("/compare")
    public List<StudentBean> getHighCGStudents(@QueryParam("id1") int id1, @QueryParam("id2") int id2) {
        StudentBean highCGStudent = studentManager.compareStudents(id1, id2);
        if (highCGStudent != null && !highCGStudents.contains(highCGStudent))
            highCGStudents.add(highCGStudent);
        return highCGStudents;
    }
}
