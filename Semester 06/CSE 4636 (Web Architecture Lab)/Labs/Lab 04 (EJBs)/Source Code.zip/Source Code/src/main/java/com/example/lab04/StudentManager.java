package com.example.lab04;

import java.util.ArrayList;
import java.util.List;

public class StudentManager {
    private List<StudentBean> students = new ArrayList<>();

    public StudentManager() {
        students.add(new StudentBean(0, "Alex", 6, 3.80, "0123456789"));
        students.add(new StudentBean(1, "Trudy", 3, 3.5, "12345678890"));
        students.add(new StudentBean(2, "Lucy", 1, 2.9, "23435678901"));
    }

    public List<StudentBean> getStudents() {
        return students;
    }

    public StudentBean getStudent(int id) {
        for(StudentBean student : students) {
            if (student.getId() == id)  return student;
        }
        return null;
    }

    public StudentBean compareStudents(int id1, int id2) {
        double std1CGPA = 0, std2CGPA = 0;
        StudentBean std1 = null, std2 = null;
        for(StudentBean student : students) {
            if (student.getId() == id1) {
                std1CGPA = student.getCgpa();
                std1 = student;
            }
            if (student.getId() == id2) {
                std2CGPA = student.getCgpa();
                std2 = student;
            }
            if (std1 != null && std2 != null)   break;
        }
        if (std1 == null || std2 == null)   return null;
        return std1CGPA > std2CGPA ? std1 : std2;
    }
}
