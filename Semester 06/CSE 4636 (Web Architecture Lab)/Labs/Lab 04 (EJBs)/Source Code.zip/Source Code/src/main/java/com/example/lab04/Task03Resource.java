package com.example.lab04;

import javax.ejb.AccessTimeout;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.enterprise.context.RequestScoped;
import javax.json.JsonObject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Singleton
@Path("/task3")
public class Task03Resource {
    List<TeeShirtRequest> teeShirtRequests = new ArrayList<>();
    @POST
    @Path("/submit")
    @Consumes(MediaType.APPLICATION_JSON)
    @Lock(LockType.WRITE)
    @AccessTimeout(value = 60, unit = TimeUnit.SECONDS)
    public void addRequest(JsonObject requestJson) {
        String choice1 = requestJson.getString("choice1");
        String choice2 = requestJson.getString("choice2");
        String choice3 = requestJson.getString("choice3");
        teeShirtRequests.add(new TeeShirtRequest(choice1, choice2, choice3));
    }
}
