package com.example.lab01;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText num1, num2;
    TextView result, operator;
    ImageButton addButton, subtractButton, multiplyButton, divideButton;

    public void onClick(View v) {
        if (num1.getText().toString().length() == 0)  num1.setText("0");
        if (num2.getText().toString().length() == 0)  num2.setText("0");

        int input1 = Integer.parseInt(num1.getText().toString());
        int input2 = Integer.parseInt(num2.getText().toString());

        switch(v.getId()) {
            case R.id.add_button:
                System.out.println(R.id.add_button);
                result.setText(String.valueOf(input1 + input2));
                operator.setText("+");
                break;
            case R.id.subtract_button:
                System.out.println(R.id.subtract_button);
                result.setText(String.valueOf(input1 - input2));
                operator.setText("−");
                break;
            case R.id.multiply_button:
                System.out.println(R.id.multiply_button);
                result.setText(String.valueOf(input1 * input2));
                operator.setText("×");
                break;
            case R.id.divide_button:
                operator.setText("÷");
                if (input2 == 0) {
                    num2.setError("Cannot divide by 0");
                    break;
                }
                result.setText(String.format("%.2f", (float) input1 / input2));
                break;
            default:
                break;
        }
    }

    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                v.getBackground().setColorFilter(0xe04d646f, PorterDuff.Mode.SRC_ATOP);
                v.invalidate();
                break;
            }
            case MotionEvent.ACTION_UP: {
                v.getBackground().clearColorFilter();
                v.invalidate();
                break;
            }
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        result = findViewById(R.id.results_view);
        operator = findViewById(R.id.selected_symbol);

        addButton = findViewById(R.id.add_button);
        subtractButton = findViewById(R.id.subtract_button);
        multiplyButton = findViewById(R.id.multiply_button);
        divideButton = findViewById(R.id.divide_button);

        addButton.setOnClickListener(this::onClick);
        subtractButton.setOnClickListener(this::onClick);
        multiplyButton.setOnClickListener(this::onClick);
        divideButton.setOnClickListener(this::onClick);

        addButton.setOnTouchListener(this::onTouch);
        subtractButton.setOnTouchListener(this::onTouch);
        multiplyButton.setOnTouchListener(this::onTouch);
        divideButton.setOnTouchListener(this::onTouch);
    }
}