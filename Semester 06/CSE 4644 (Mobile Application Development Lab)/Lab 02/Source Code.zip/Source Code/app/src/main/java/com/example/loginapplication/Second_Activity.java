package com.example.loginapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Second_Activity extends AppCompatActivity {

    String getUsername() {
        if (getIntent().hasExtra("com.example.loginapplication.username"))
            return getIntent().getStringExtra("com.example.loginapplication.username");
        else    return "";
    }

    void goToThirdActivity() {
        Intent intent = new Intent(getApplicationContext(), Third_Activity.class);
        startActivity(intent);
    }

    void init() {
        TextView userField = findViewById(R.id.userView);
        userField.setText(getUsername());
        Button homepage = findViewById(R.id.homepage);
        homepage.setOnClickListener(view -> goToThirdActivity());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        init();
    }
}