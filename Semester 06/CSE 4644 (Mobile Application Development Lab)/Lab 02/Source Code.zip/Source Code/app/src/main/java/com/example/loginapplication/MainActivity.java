package com.example.loginapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button loginButton;
    EditText userField;
    EditText passField;

    void goToSecondActivity() {
        String username = userField.getText().toString();
        String password = passField.getText().toString();

        Intent intent = new Intent(getApplicationContext(), Second_Activity.class);
        intent.putExtra("com.example.loginapplication.username", username);
        startActivity(intent);
    }

    void init() {
        loginButton = findViewById(R.id.login);
        userField = findViewById(R.id.user);
        passField = findViewById(R.id.pass);
        loginButton.setOnClickListener(view -> goToSecondActivity());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
}