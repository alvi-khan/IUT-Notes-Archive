public class Circle extends Shape {

    Circle(String colour) {
        super(colour);
    }

    @Override
    public void display() {
        System.out.println("A " + colour + " circle.");
    }
}
