public abstract class Shape implements Object {
    String colour;

    Shape(String colour) {
        this.colour = colour;
    }
}
