public class Water extends Village {
    Water() {
        addObject(new Rectangle("blue"));
    }

    @Override
    public void display() {
        System.out.println("Water:");
        super.display();
    }
}
