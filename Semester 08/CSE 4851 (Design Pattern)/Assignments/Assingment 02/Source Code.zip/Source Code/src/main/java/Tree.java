public class Tree extends Village {
    Tree() {
        addObject(new Circle("green"));
        addObject(new Rectangle("brown"));
    }

    @Override
    public void display() {
        System.out.println("Tree:");
        super.display();
    }
}
