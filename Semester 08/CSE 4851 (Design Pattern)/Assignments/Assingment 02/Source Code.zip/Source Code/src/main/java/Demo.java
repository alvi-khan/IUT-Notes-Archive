public class Demo {
    public static void main(String[] args) {
        Village village = new Village();
        village.addObject(new House());
        village.addObject(new Tree());
        village.addObject(new Water());

        village.display();
    }

    // Object and Shape classes exist for abstraction. Not part of composite pattern.
    // 4 types of shapes: Circle, Rectangle, Square and Triangle.

    // Composite pattern starts from Village. It is an object which contains other objects.
    // Village contains House, Tree, and Water.
    // House contains Triangle and Square.
    // Tree contains Circle and Rectangle.
    // Water contains Rectangle.
}
