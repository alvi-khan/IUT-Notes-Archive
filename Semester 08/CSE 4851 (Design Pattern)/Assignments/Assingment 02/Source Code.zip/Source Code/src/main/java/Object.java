public interface Object {
    void display();
}
