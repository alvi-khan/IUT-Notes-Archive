public class Triangle extends Shape {
    Triangle(String colour) {
        super(colour);
    }

    @Override
    public void display() {
        System.out.println("A " + colour + " triangle.");
    }
}
