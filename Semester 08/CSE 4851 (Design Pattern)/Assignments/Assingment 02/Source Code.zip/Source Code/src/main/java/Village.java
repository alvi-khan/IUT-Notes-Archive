import java.util.ArrayList;
import java.util.List;

public class Village implements Object {
    private List<Object> objects = new ArrayList<>();

    public void addObject(Object object) {
        objects.add(object);
    }

    @Override
    public void display() {
        for (Object object : objects) {
            object.display();
        }
    }
}
