public class House extends Village {
    public House() {
        addObject(new Triangle("red"));
        addObject(new Square("white"));
    }

    @Override
    public void display() {
        System.out.println("House:");
        super.display();
    }
}
