public class Square extends Shape {
    Square(String colour) {
        super(colour);
    }

    @Override
    public void display() {
        System.out.println("A " + colour + " square.");
    }
}
