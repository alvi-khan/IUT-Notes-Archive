public class Rectangle extends Shape {
    Rectangle(String colour) {
        super(colour);
    }

    @Override
    public void display() {
        System.out.println("A " + colour + " rectangle.");
    }
}
