public interface ImageItem {
    public void accept(ImageItemVisitor visitor);
}
