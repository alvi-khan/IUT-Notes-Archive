public interface ImageItemVisitor {
    void visit(JPEGImage image);
    void visit(PNGImage image);
    void visit(RAWImage image);
    void visit(Gallery gallery);
}
