public class PNGImage implements ImageItem {
    @Override
    public void accept(ImageItemVisitor visitor) {
        visitor.visit(this);
    }
}
