public class ImageItemVisitorImpl implements ImageItemVisitor {
    @Override
    public void visit(JPEGImage image) {
        System.out.println("Displaying JPEG Image.");
    }

    @Override
    public void visit(PNGImage image) {
        System.out.println("Displaying PNG Image.");
    }

    @Override
    public void visit(RAWImage image) {
        System.out.println("Displaying RAW Image.");
    }

    @Override
    public void visit(Gallery gallery) {
        System.out.println("Displaying Image Gallery.");
    }
}
