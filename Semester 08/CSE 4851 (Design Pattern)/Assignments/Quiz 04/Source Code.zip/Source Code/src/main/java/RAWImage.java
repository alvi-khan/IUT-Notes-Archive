public class RAWImage implements ImageItem {
    @Override
    public void accept(ImageItemVisitor visitor) {
        visitor.visit(this);
    }
}
