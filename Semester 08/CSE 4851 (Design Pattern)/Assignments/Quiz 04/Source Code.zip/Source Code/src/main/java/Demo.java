public class Demo {
    public static void main(String[] args) {
        Gallery gallery = new Gallery();
        gallery.addImage(new PNGImage());
        gallery.addImage(new JPEGImage());
        gallery.addImage(new RAWImage());
        gallery.accept(new ImageItemVisitorImpl());
    }

    // Scenario: Using the visitor pattern to display a gallery of images.
}
