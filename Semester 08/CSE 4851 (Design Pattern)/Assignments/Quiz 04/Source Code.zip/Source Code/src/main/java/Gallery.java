import java.util.ArrayList;
import java.util.List;

public class Gallery implements ImageItem {
    List<ImageItem> images = new ArrayList<>();

    public void addImage(ImageItem image) {
        images.add(image);
    }

    @Override
    public void accept(ImageItemVisitor visitor) {
        for (ImageItem image : images) {
            image.accept(visitor);
        }
        visitor.visit(this);
    }
}
