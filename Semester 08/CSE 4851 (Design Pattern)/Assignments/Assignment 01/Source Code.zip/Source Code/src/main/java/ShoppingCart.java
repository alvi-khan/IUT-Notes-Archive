import shippingStrategy.ShippingStrategy;
import toy.Toy;

public class ShoppingCart {
    ShippingStrategy shippingStrategy;
    Toy toy;
    ToyFactory toyFactory = new ToyFactory();

    public void manufactureToy(String toyType) {
        toy = toyFactory.createToy(toyType);
    }

    public void setShippingStrategy(ShippingStrategy shippingStrategy) {
        this.shippingStrategy = shippingStrategy;
    }

    public void ship() {
        shippingStrategy.ship();
    }
}
