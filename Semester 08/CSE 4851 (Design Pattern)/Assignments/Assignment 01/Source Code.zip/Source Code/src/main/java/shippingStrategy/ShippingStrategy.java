package shippingStrategy;

public interface ShippingStrategy {
    void ship();
}
