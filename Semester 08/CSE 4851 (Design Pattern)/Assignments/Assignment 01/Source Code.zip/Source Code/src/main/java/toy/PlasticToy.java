package toy;

public class PlasticToy implements Toy {
    @Override
    public void play() {
        // add childhood joy
    }
}
