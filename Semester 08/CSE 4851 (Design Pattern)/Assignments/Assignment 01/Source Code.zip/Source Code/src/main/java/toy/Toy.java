package toy;

public interface Toy {
    void play();
}
