package shippingStrategy;

public class RegularShipping implements ShippingStrategy {
    @Override
    public void ship() {
        System.out.println("Shipping via Snail Mail");
    }
}
