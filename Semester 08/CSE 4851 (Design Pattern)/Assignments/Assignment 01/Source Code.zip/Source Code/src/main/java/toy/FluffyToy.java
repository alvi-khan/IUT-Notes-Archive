package toy;

public class FluffyToy implements Toy {
    @Override
    public void play() {
        // add fluffiness
    }
}
