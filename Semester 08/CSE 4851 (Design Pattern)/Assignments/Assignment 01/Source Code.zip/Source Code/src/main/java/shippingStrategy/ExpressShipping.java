package shippingStrategy;

public class ExpressShipping implements ShippingStrategy {
    @Override
    public void ship() {
        System.out.println("Shipping via Amazon Prime™");
    }
}
