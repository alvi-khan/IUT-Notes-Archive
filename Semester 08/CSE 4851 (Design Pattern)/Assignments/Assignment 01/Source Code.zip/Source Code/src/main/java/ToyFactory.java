import toy.*;

public class ToyFactory {
    Toy sadness = null;
    public Toy createToy(String toyType) {
        if (toyType.equals("plastic")) {
            return new PlasticToy();
        } else if (toyType.equals("fluffy")) {
            return new FluffyToy();
        }
        return sadness;
    }
}
