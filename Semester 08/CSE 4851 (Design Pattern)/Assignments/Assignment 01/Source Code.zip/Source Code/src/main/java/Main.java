import shippingStrategy.ExpressShipping;
import shippingStrategy.RegularShipping;
import shippingStrategy.ShippingStrategy;

import java.util.Scanner;

/**
 * Scenario: Gift shop that allows customers to choose toys and a shipping strategy.
 * Toys are managed using Factory Pattern.
 * Shipping strategy is managed using Strategy Pattern.
 */

public class Main {
    public static void main(String[] args) {
        ShoppingCart shoppingCart = new ShoppingCart();
        Scanner input = new Scanner(System.in);

        System.out.println("Please choose a toy (fluffy, plastic):");
        String toyType = input.nextLine();
        if (toyType.equals("fluffy") || toyType.equals("plastic")) {
            shoppingCart.manufactureToy(toyType);
        } else {
            System.out.println("Invalid choice.");
            return;
        }

        System.out.println("Please choose shipping strategy:");
        System.out.println("1. Regular\n2. Express");
        int strategyChoice = input.nextInt();
        ShippingStrategy shippingStrategy;
        if (strategyChoice == 1)        shippingStrategy = new RegularShipping();
        else if (strategyChoice == 2)   shippingStrategy = new ExpressShipping();
        else {
            System.out.println("Invalid choice.");
            return;
        }
        shoppingCart.setShippingStrategy(shippingStrategy);
        shoppingCart.ship();
    }
}
